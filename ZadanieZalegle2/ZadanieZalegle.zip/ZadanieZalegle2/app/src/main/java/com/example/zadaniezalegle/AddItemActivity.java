package com.example.zadaniezalegle;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText titleEditText, priceEditText, descriptionEditText;
    private Button saveButton;
    private DataAsyncTask dataAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        titleEditText = findViewById(R.id.titleEditText);
        priceEditText = findViewById(R.id.priceEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        saveButton = findViewById(R.id.saveButton);

        // Tworzymy instancję DataAsyncTask
        dataAsyncTask = new DataAsyncTask(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ItemListManager.getItemList()));

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString();
                String price = priceEditText.getText().toString();
                String description = descriptionEditText.getText().toString();

                // Tworzymy nowy przedmiot
                Item newItem = new Item(title, price, description);

                // Przekazujemy przedmiot do dodania
                dataAsyncTask.addItemToList(newItem);

                // Zakończ aktywność po zapisaniu
                finish();
            }
        });
    }
}
