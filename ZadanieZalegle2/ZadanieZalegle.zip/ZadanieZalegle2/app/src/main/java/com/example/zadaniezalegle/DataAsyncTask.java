package com.example.zadaniezalegle;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.util.Log;

public class DataAsyncTask extends AsyncTask<Void, Void, Void> {
    private static final int REFRESH_INTERVAL = 50000; // Odświeżanie co 5 sekund
    private ArrayAdapter<Item> adapter;

    public DataAsyncTask(ArrayAdapter<Item> adapter) {
        this.adapter = adapter;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            while (!isCancelled()) {
                Thread.sleep(REFRESH_INTERVAL);
                publishProgress();  // Co 5 sekund wywołujemy odświeżenie danych
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);

        // Odświeżenie danych w adapterze
        // Nie dodajemy nowych danych, tylko odświeżamy widok
        adapter.notifyDataSetChanged();
    }

    // Dodaj element do listy (jeśli nie istnieje)
    public void addItemToList(Item item) {
        ItemListManager.addItem(item);
    }

    // Edytuj element w liście
    public void editItemInList(int index, Item updatedItem) {
        ItemListManager.updateItem(index, updatedItem);
    }
}
