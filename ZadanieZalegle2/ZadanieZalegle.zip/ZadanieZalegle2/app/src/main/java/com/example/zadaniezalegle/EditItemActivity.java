package com.example.zadaniezalegle;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditItemActivity extends AppCompatActivity {

    private EditText titleEditText, priceEditText, descriptionEditText;
    private Button saveButton;
    private int itemIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        itemIndex = getIntent().getIntExtra("itemIndex", -1);
        titleEditText = findViewById(R.id.titleEditText);
        priceEditText = findViewById(R.id.priceEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        saveButton = findViewById(R.id.saveButton);

        // Ustawienie danych istniejącego przedmiotu do edycji
        Item itemToEdit = ItemListManager.getItemList().get(itemIndex);
        titleEditText.setText(itemToEdit.getTitle());
        priceEditText.setText(itemToEdit.getPrice());
        descriptionEditText.setText(itemToEdit.getDescription());

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString();
                String price = priceEditText.getText().toString();
                String description = descriptionEditText.getText().toString();

                // Zaktualizowanie przedmiotu
                Item updatedItem = new Item(title, price, description);
                DataAsyncTask dataAsyncTask = new DataAsyncTask(new ArrayAdapter<>(EditItemActivity.this, android.R.layout.simple_list_item_1, ItemListManager.getItemList()));
                dataAsyncTask.editItemInList(itemIndex, updatedItem);

                // Powrót do głównej aktywności
                finish();
            }
        });
    }
}
