package com.example.zadaniezalegle;
import java.util.ArrayList;
import java.util.List;

public class ItemListManager {
    private static List<Item> itemList = new ArrayList<>();

    // Pobierz całą listę
    public static List<Item> getItemList() {
        return itemList;
    }

    // Dodaj nowy przedmiot (jeśli nie istnieje)
    public static void addItem(Item item) {
        // Sprawdź, czy przedmiot już istnieje (np. na podstawie tytułu)
        for (Item existingItem : itemList) {
            if (existingItem.getTitle().equals(item.getTitle())) {
                return; // Element już istnieje, nie dodawaj go ponownie
            }
        }
        itemList.add(item);
    }

    // Zaktualizuj istniejący przedmiot
    public static void updateItem(int index, Item updatedItem) {
        if (index >= 0 && index < itemList.size()) {
            itemList.set(index, updatedItem);
        }
    }

    // Inicjalizacja przykładowych danych
    public static void initializeSampleData() {
        // Dodaj tylko raz przykładowe dane
        if (itemList.isEmpty()) {
            itemList.add(new Item("Product 1", "31", "Masło stare"));
            itemList.add(new Item("Product 2", "12", "Lubię to i owo"));
            itemList.add(new Item("Product 3", "15", "Jabłka z sadu"));
        }
    }
}
