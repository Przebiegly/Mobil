package com.example.zadaniezalegle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ListViewActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<Item> adapter;
    private DataAsyncTask dataAsyncTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);

        listView = findViewById(R.id.listView);

        // Inicjalizuj przykładowe dane tylko raz
        ItemListManager.initializeSampleData();

        // Adapter dla ListView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ItemListManager.getItemList());
        listView.setAdapter(adapter);

        // Tworzymy instancję DataAsyncTask
        dataAsyncTask = new DataAsyncTask(adapter);
        dataAsyncTask.execute();  // Uruchamiamy wątek do odświeżania listy

        // Obsługa kliknięcia na przedmiot w liście
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parentView, View view, int position, long id) {
                // Przekazujemy indeks przedmiotu do edycji
                Intent intent = new Intent(ListViewActivity.this, EditItemActivity.class);
                intent.putExtra("itemIndex", position);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dataAsyncTask != null && !dataAsyncTask.isCancelled()) {
            dataAsyncTask.cancel(true);
        }
    }
}
